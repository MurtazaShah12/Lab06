﻿using System;

namespace Example5
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> intList = new List<int>() { 10, 20, 30, 40 };

            int elem = intList[1];
        }
    }
}